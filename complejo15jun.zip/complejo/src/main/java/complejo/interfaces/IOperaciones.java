package complejo.interfaces;

import java.sql.SQLException;

import complejo.vo.ClienteVO;

public interface IOperaciones {
    void insertar(ClienteVO cliente) throws SQLException; 
    void buscarCliente(int dni) throws SQLException;
}
