package complejo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Provincia {
	private Integer id;
	private String nombre;
	private String ciudades;
	private String partidos;
	private Integer poblacion;
	static Connection conexion = Conexion.conectar();
	static Statement stmt;

	public Provincia(Integer id, String nombre, String ciudades, String partidos, Integer poblacion) {
		this.id = id;
		this.nombre = nombre;
		this.ciudades = ciudades;
		this.partidos = partidos;
		this.poblacion = poblacion;
	}

	public Provincia(String nombre, String ciudades, String partidos, Integer poblacion) {
		this.nombre = nombre;
		this.ciudades = ciudades;
		this.partidos = partidos;
		this.poblacion = poblacion;
	}

	public Provincia() {

	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getCiudades() {
		return ciudades;
	}

	public void setCiudades(String ciudades) {
		this.ciudades = ciudades;
	}

	public String getPartidos() {
		return partidos;
	}

	public void setPartidos(String partidos) {
		this.partidos = partidos;
	}

	public Integer getPoblacion() {
		return poblacion;
	}

	public void setPoblacion(Integer poblacion) {
		this.poblacion = poblacion;
	}

	@Override
	public String toString() {
		return "Provincia [id=" + id + ", nombre=" + nombre + ", ciudades=" + ciudades + ", partidos=" + partidos
				+ ", poblacion=" + poblacion + "]";
	}

	// INSERTAR--> INSERT INTO...
	public void insertar(Provincia p) throws SQLException {
		try {
			// paso 1 tener la conexión
			// Connection conexion = Conexion.conectar();
			// paso 2 armar el query
			String sql = "INSERT INTO provincias"
					+ "(nombre,ciudades,partidos,poblacion) "
					+ "VALUES ('" + p.getNombre() + "','" + p.getCiudades() + "',"
					+ "'" + p.getPartidos() + "','" + p.getPoblacion() + "')";
			// paso 3 crear estado
			stmt = conexion.createStatement();
			// paso 4 ejecutamos
			stmt.execute(sql);
			System.out.println("Guardamosssss");

		} catch (Exception e) {
			System.out.println("Error no pude guardar ;(");
			e.printStackTrace();
		} finally {
			// opcionales
			stmt.close();
			conexion.close();
		}
	}

	// DELETE
	public static void borrar(int id) throws SQLException {
		try {
			// Connection conexion = Conexion.conectar();
			String query = "DELETE FROM provincias WHERE id = '" + id + "'";
			stmt = conexion.createStatement();
			stmt.execute(query);
			System.out.println("Registro eliminado correctamente");
			stmt.close();
			conexion.close();
		} catch (Exception e) {
			System.out.println("Error no pude eliminar ;(");
			e.printStackTrace();
		}
	}

	// UPDATE
	public void editar(Provincia p) throws SQLException {
		try {
			String sql = "UPDATE provincias SET nombre = '" + p.getNombre() + "',"
					+ "ciudades = '" + p.getCiudades() + "',"
					+ "partidos = '" + p.getPartidos() + "', poblacion = '" + p.getPoblacion() + "'"
					+ " WHERE id = '" + p.getId() + "'";
			stmt = conexion.createStatement();
			stmt.execute(sql);
			System.out.println("Editado correctamente");
		} catch (Exception e) {
			System.out.println("Error no pude editar ;(");
			e.printStackTrace();
		} finally {
			stmt.close();
			conexion.close();
		}
	}

	// LISTAR
	public static void listar() throws SQLException {
		try {
			String sql = "SELECT *FROM provincias";
			stmt = conexion.createStatement();
			ResultSet datos = stmt.executeQuery(sql);
			System.out.println("Mostrando datos:");
			while (datos.next()) {
				System.out.println("Id: " + datos.getInt("id"));
				System.out.println("Nombre: " + datos.getString("nombre"));
				System.out.println("Ciudades: " + datos.getString("ciudades"));
				System.out.println("Partidos: " + datos.getString("partidos"));
				System.out.println("Población: " + datos.getInt("poblacion"));
				//System.out.println(datos.getObject("nombre"));
				// System.out.println(datos.getObject(2));
				System.out.println("\t********************\n");
			}
		} catch (Exception e) {
			System.out.println("Error no pudo mostrar ;(");
			e.printStackTrace();
		} finally {
			stmt.close();
			conexion.close();
		}
	}

}
