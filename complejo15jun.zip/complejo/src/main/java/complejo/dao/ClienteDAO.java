package complejo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import complejo.Conexion;
import complejo.interfaces.IOperaciones;
import complejo.vo.ClienteVO;

public class ClienteDAO implements IOperaciones {
    // DAO manejamos los datos del objeto
    // manejo de transacciones: commit, rollback
    // sentencias preparadas jdbc (sumar seguridad(sql injection), velocidad)
    static Connection conexion = Conexion.conectar();
    static PreparedStatement stmt = null;
    static ResultSet resultado;

    @Override
    public void insertar(ClienteVO cliente) throws SQLException {
        try {
            // quitar el modo automático de JTA
            conexion.setAutoCommit(false);
            String query = "INSERT INTO cliente VALUES (?,?,?,?)";
            stmt = conexion.prepareStatement(query);
            stmt.setInt(1, cliente.getDni());
            stmt.setString(2, cliente.getNombre());
            stmt.setString(3, cliente.getApellido());
            stmt.setString(4, cliente.getCorreo());
            stmt.execute();
            System.out.println("Guardado correctamente!");
            conexion.commit();// confirmamos el la bd jta
        } catch (Exception e) {
            System.out.println("Ups no puedo guardar!");
            e.printStackTrace();
            try {
                System.out.println("haciendo rollback en 3,2,1...");
                conexion.rollback();// revertimos la operación jta
            } catch (Exception e2) {
                System.out.println("Ups error con el rollback");
                System.out.println(e2.getMessage());
                e2.printStackTrace();
            }
        } finally {
            stmt.close();
            conexion.close();
        }

    }

    @Override
    public void buscarCliente(int dni) throws SQLException {
        try {
            // quitar el modo automático de JTA
            conexion.setAutoCommit(false);
            String query = "SELECT nombre,apellido FROM cliente WHERE dni = ?";
            stmt = conexion.prepareStatement(query);
            stmt.setInt(1, dni);

            resultado = stmt.executeQuery();
            System.out.println("Datos:");
            while (resultado.next()) {
                System.out.println(
                        "Nombre: " + resultado.getString("nombre") + ", Apellido: " + resultado.getString("apellido"));
            }
            conexion.commit();// confirmamos el la bd jta
        } catch (Exception e) {
            System.out.println("Ups no puedo guardar!");
            e.printStackTrace();
            try {
                System.out.println("haciendo rollback en 3,2,1...");
                conexion.rollback();// revertimos la operación jta
            } catch (Exception e2) {
                System.out.println("Ups error con el rollback");
                System.out.println(e2.getMessage());
                e2.printStackTrace();
            }
        } finally {
            stmt.close();
            conexion.close();
        }
    }
    //modificar
    //eliminar
}
