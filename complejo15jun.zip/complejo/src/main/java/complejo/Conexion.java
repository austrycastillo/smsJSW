package complejo;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexion {
	static Connection conexion = null;

	public static Connection conectar() {
		try {
			//Class.forName("com.mysql.cj");
			conexion = DriverManager.getConnection("jdbc:mysql://localhost/pais", "root", "");
			System.out.println("SIII conecto");
		} catch (Exception e) {
			System.out.println("NOOO conecto");
			e.printStackTrace();
		}
		return conexion;
	}
}
