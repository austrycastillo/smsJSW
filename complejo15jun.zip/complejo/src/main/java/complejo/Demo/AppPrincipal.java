package complejo.Demo;

import java.sql.SQLException;

import complejo.Conexion;
import complejo.Provincia;
import complejo.dao.ClienteDAO;
import complejo.vo.ClienteVO;

public class AppPrincipal {

	public static void main(String[] args) throws SQLException {
		// Conexion.conectar();
		// //insert
		// Provincia a = new Provincia("Mendoza","Mendoza","Uno, Dos",253754);
		// a.insertar(a);
		//delete
		//Provincia.borrar(3);
		//editar
		//  Provincia b = new Provincia(1,"Jujuy","La Quiaca 2 ","La Quiaquita 2 ",100);
		//  b.editar(b);
		//listar
		// Provincia.listar();
		//****sentencias preparadas */
		//insertar
		//crear objetos de tipo vo
		// ClienteVO cliente1 = new ClienteVO(123,"Pepe","Perez","pp@correo.com");
		// ClienteVO cliente2 = new ClienteVO(456,"Juana","Alonso","ja@correo.com");
		// ClienteVO cliente3 = new ClienteVO(789,"Filomena","Pulkoski","filo@correo.com");
		ClienteDAO clienteDAO = new ClienteDAO();
		// clienteDAO.insertar(cliente1);
		//clienteDAO.insertar(cliente2);
		//clienteDAO.insertar(cliente3);
		//buscar un cliente
		clienteDAO.buscarCliente(789);
	}	

}
